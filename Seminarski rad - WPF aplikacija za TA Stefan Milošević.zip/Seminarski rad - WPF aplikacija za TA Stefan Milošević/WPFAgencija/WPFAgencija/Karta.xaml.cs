﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WPFAgencija;

namespace WPFAgencija
{
    public partial class Karta : Window
    {


        public Karta()
        {
            InitializeComponent();
            binDataGrid();
        }

        private void binDataGrid()
        {

            SqlConnection connection = new SqlConnection();
            connection.ConnectionString = ConfigurationManager.ConnectionStrings["TuristickaAgencija"].ConnectionString;
            connection.Open();
            SqlCommand command = new SqlCommand();
            command.CommandText = "SELECT * FROM  [Karta] INNER JOIN [Destinacija] ON [Karta].ID_destinacije = [Destinacija].ID_destinacije INNER JOIN [Klijent] ON [Karta].ID_klijenta = [Klijent].ID_klijenta";
            command.Connection = connection;
            SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
            DataTable dataTable = new DataTable("Karta");
            dataAdapter.Fill(dataTable);

            DataGrid.ItemsSource = dataTable.DefaultView;
        }

        private void ponistiUnosTxt()
        {
            txtID_karte.Text = "";
            txtCena.Text = "";
            dtDatum.Text = "";
            lbxDestinacija.SelectedValue = "";
            cbxID_klijenta.SelectedValue = "";
        }
        private void Dodaj_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection connection = new SqlConnection();
            connection.ConnectionString = ConfigurationManager.ConnectionStrings["TuristickaAgencija"].ConnectionString;
            connection.Open();
            DateTime Datum = Convert.ToDateTime(dtDatum.Text);
            string myDate = "30-12-1899 07:50:00:AM";
            DateTime dt1 = DateTime.ParseExact(myDate, "dd-MM-yyyy hh:mm:ss:tt",
                                                       CultureInfo.InvariantCulture);
            SqlCommand command = new SqlCommand();
            command.CommandText = "INSERT INTO [Karta](Cena, Datum, ID_destinacije,ID_klijenta, ID_klase) VALUES(@Cena, @Datum, @ID_destinacije, @ID_klijenta, @ID_klase)";
            command.Parameters.AddWithValue("@Cena", txtCena.Text);
            command.Parameters.AddWithValue("@Datum", dtDatum.SelectedDate);
            command.Parameters.AddWithValue("@ID_destinacije", lbxDestinacija.SelectedValue);
            command.Parameters.AddWithValue("@ID_klijenta ", cbxID_klijenta.SelectedValue);
            command.Parameters.AddWithValue("@ID_klase ", cbxID_klase.SelectedValue);

            command.Connection = connection;
            int provera = command.ExecuteNonQuery();
            if (provera == 1)
            {
                MessageBox.Show("Podaci su uspešno upisani");
                binDataGrid();
            }
            ponistiUnosTxt();
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            DataGrid dg = sender as DataGrid;
            DataRowView dr = dg.SelectedItem as DataRowView;
            if (dr != null)
            {
                txtID_karte.Text = dr["ID_karte"].ToString();
                txtCena.Text = dr["Cena"].ToString();
                dtDatum.Text = dr["Datum"].ToString();
                lbxDestinacija.SelectedValue = dr["ID_destinacije"].ToString();
                cbxID_klijenta.Text = dr["ID_klijenta"].ToString();
                cbxID_klase.Text = dr["ID_klase"].ToString();
            }
        }

        private void Obrisi_Click(object sender, RoutedEventArgs e)
        {
            {
                SqlConnection connection = new SqlConnection();
                connection.ConnectionString = ConfigurationManager.ConnectionStrings["TuristickaAgencija"].ConnectionString;
                connection.Open();
                SqlCommand command = new SqlCommand();
                command.CommandText = "DELETE FROM [Karta] WHERE ID_karte = @ID_karte";
                command.Parameters.AddWithValue("@ID_karte", txtID_karte.Text);
                command.Connection = connection;
                int provera = command.ExecuteNonQuery();
                if (provera == 1)
                {
                    MessageBox.Show("Podaci su uspešno obrisani");
                    binDataGrid();
                }
                ponistiUnosTxt();
            }
        }
        private void Izmeni_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection connection = new SqlConnection();
            connection.ConnectionString = ConfigurationManager.ConnectionStrings["TuristickaAgencija"].ConnectionString;
            connection.Open();
            SqlCommand command = new SqlCommand();
            command.CommandText = "UPDATE [Karta] SET Cena = @Cena, Datum = @Datum, ID_destinacije = @ID_destinacije, ID_klijenta = @ID_klijenta WHERE ID_karte = @ID_karte";
            command.Parameters.AddWithValue("@ID_karte", txtID_karte.Text);
            command.Parameters.AddWithValue("@Cena", txtCena.Text);
            command.Parameters.AddWithValue("@Datum", dtDatum.SelectedDate);
            command.Parameters.AddWithValue("@ID_destinacije", lbxDestinacija.SelectedItem);
            command.Parameters.AddWithValue("@ID_klijenta", cbxID_klijenta.Text);
            command.Parameters.AddWithValue("@ID_klase", cbxID_klase.Text);

            command.Connection = connection;
            int provera = command.ExecuteNonQuery();
            if (provera == 1)
            {
                MessageBox.Show("Podaci su uspešno promenjeni");
                binDataGrid();
            }
            ponistiUnosTxt();

        }

        private void ListBox_Loaded(object sender, RoutedEventArgs e)
        {
            SqlConnection connection = new SqlConnection();
            connection.ConnectionString = ConfigurationManager.ConnectionStrings["TuristickaAgencija"].ConnectionString;
            connection.Open();
            SqlCommand commandLbx = new SqlCommand();
            commandLbx.CommandText = "SELECT * FROM [Destinacija] ORDER BY ID_destinacije";
            commandLbx.Connection = connection;
            SqlDataAdapter dataAdapterLbx = new SqlDataAdapter(commandLbx);
            DataTable dataTableLbx = new DataTable("Karta");
            dataAdapterLbx.Fill(dataTableLbx);

            for (int i = 0; i < dataTableLbx.Rows.Count; i++)
            {
                lbxDestinacija.Items.Add(dataTableLbx.Rows[i]["Ime"]);
            }
        }

        private void cbxID_klijenta_Loaded(object sender, RoutedEventArgs e)
        {
            SqlConnection connection = new SqlConnection();
            connection.ConnectionString = ConfigurationManager.ConnectionStrings["TuristickaAgencija"].ConnectionString;
            connection.Open();
            SqlCommand commandCbx = new SqlCommand();
            commandCbx.CommandText = "SELECT * FROM [Klijent] ORDER BY ID_klijenta";
            commandCbx.Connection = connection;
            SqlDataAdapter dataAdapterCbx = new SqlDataAdapter(commandCbx);
            DataTable dataTableCbx = new DataTable("Karta");
            dataAdapterCbx.Fill(dataTableCbx);
            for (int i = 0; i < dataTableCbx.Rows.Count; i++)
            {
                cbxID_klijenta.Items.Add(dataTableCbx.Rows[i]["ID_klijenta"]);
            }
        }

        private void cbxID_klase_Loaded(object sender, RoutedEventArgs e)
        {
            SqlConnection connection = new SqlConnection();
            connection.ConnectionString = ConfigurationManager.ConnectionStrings["TuristickaAgencija"].ConnectionString;
            connection.Open();
            SqlCommand commandCbx = new SqlCommand();
            commandCbx.CommandText = "SELECT * FROM [Klase] ORDER BY ID_klase";
            commandCbx.Connection = connection;
            SqlDataAdapter dataAdapterCbx = new SqlDataAdapter(commandCbx);
            DataTable dataTableCbx = new DataTable("Karta");
            dataAdapterCbx.Fill(dataTableCbx);
            for (int i = 0; i < dataTableCbx.Rows.Count; i++)
            {
                cbxID_klijenta.Items.Add(dataTableCbx.Rows[i]["Broj_sedišta"]);
            }
        }

        private void Nazad_Click(object sender, RoutedEventArgs e)
        {
            MainWindow objMainWindow = new MainWindow();
            this.Visibility = Visibility.Hidden;
            objMainWindow.Show();
        }
    }
}
